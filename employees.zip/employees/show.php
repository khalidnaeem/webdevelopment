<?php
require 'connection.php';
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <title></title>
  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css">
  <!-- Bootstrap core CSS -->
  <link href="css/bootstrap.min.css" rel="stylesheet">
  <!-- Material Design Bootstrap -->
  <link href="css/mdb.min.css" rel="stylesheet">
  <!-- Your custom styles (optional) -->
  <link href="css/style.css" rel="stylesheet">
</head>

<body>

  <!-- Table -->
  <div class="container-fluid mt-3">
    <h1 class="text-center">All Employees Data</h1>
  <table class="table table-bordered table-striped">
    <tr>
    <th>ID</th>
    <th>Username</th>
    <th>Email</th>
    <th>Mobile #</th>
    <th>Full Name</th>
    <th>Company</th>
    <th>Salary</th>
    <th>Address</th>
    <th>CNIC</th>
    <th>Bank Acc.Title</th>
    <th>Bank Acc.#</th>
    <th>Bank Swift</th>
    <th>Joining Date</th>
    <th>Guardian Name</th>
    <th colspan="2">Actions</th>
    </tr>
    <!--php starts here -->
    <?php 
    //getting all query from database
    $fetch = "SELECT * FROM users";
    //getting the query
    $execute = mysqli_query($conn,$fetch);
    //showing all the values from database
    foreach ($execute as $fetcher) {
      $ids = $fetcher['id'];
      echo "<tr align='center'>";
      echo "<td>".$fetcher['id']."</td>";
      echo "<td>".$fetcher['username']."</td>";
      echo "<td>".$fetcher['email']."</td>";
      echo "<td>".$fetcher['mobilenumber']."</td>";
      echo "<td>".$fetcher['fullname']."</td>";
      echo "<td>".$fetcher['company']."</td>";
      echo "<td>".$fetcher['salary']."</td>";
      echo "<td>".$fetcher['address']."</td>";
      echo "<td>".$fetcher['cnic']."</td>";
      echo "<td>".$fetcher['banktitle']."</td>";
      echo "<td>".$fetcher['bankaccount']."</td>";
      echo "<td>".$fetcher['bankswift']."</td>";
      echo "<td>".$fetcher['joiningdate']."</td>";
      echo "<td>".$fetcher['guardianname']."</td>";
      echo "<td><a href='edit.php?id=$ids' style='color: white'><button class='btn btn-primary'>Edit</a>";
      echo "<td><a href='delete.php?id=$ids' style='color: white'><button class='btn btn-danger'>Delete</a>";
      echo "</tr>";
    }
    ?>
  </table>
  <button class="btn btn-success"><a href="emp-reg.php" style="color: white">Add New Employee Record</a></button>
  </div>

  <!-- SCRIPTS -->
  <!-- JQuery -->
  <script type="text/javascript" src="js/jquery-3.3.1.min.js"></script>
  <!-- Bootstrap tooltips -->
  <script type="text/javascript" src="js/popper.min.js"></script>
  <!-- Bootstrap core JavaScript -->
  <script type="text/javascript" src="js/bootstrap.min.js"></script>
  <!-- MDB core JavaScript -->
  <script type="text/javascript" src="js/mdb.js"></script>
</body>

</html>
