<?php
require 'connection.php';
#starts here
//checking connection to the database
/*
if($conn){
  echo "db connected";
}else{
  echo "db not connected";
}
?> */
//getting values from the user
$UserName = $_POST['empusername'];
$Email = $_POST['empemail'];
$Mobile = $_POST['empphonenumber'];
$FullName = $_POST['empfullname'];
$Company = $_POST['empcompany'];
$Salary = $_POST['empsalary'];
$Address = $_POST['empaddress'];
$CNIC = $_POST['empcnic'];
$BankTitle = $_POST['empbanktitle'];
$BankAccountNumber = $_POST['empaccountnumber'];
$BankSwift = $_POST['empbankswift'];
$JoiningDate = $_POST['empjoindate'];
$GuardianName = $_POST['empguardianname'];

//insert query in to database
$insert = "INSERT INTO users(username, email, mobilenumber, fullname, company, salary, address, cnic, banktitle, bankaccount, bankswift, joiningdate, guardianname) VALUES('$UserName', '$Email', '$Mobile', '$FullName', '$Company', '$Salary', '$Address', '$CNIC', '$BankTitle', '$BankAccountNumber', '$BankSwift', '$JoiningDate', '$GuardianName')";
//checking database query
$result = mysqli_query($conn,$insert);

//message for database submitting data
if($result){
	echo "data inserted";
}else{
	echo "data not inserted";
}

#starts here