<?php
require 'connection.php';
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <title></title>
  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css">
  <!-- Bootstrap core CSS -->
  <link href="css/bootstrap.min.css" rel="stylesheet">
  <!-- Material Design Bootstrap -->
  <link href="css/mdb.min.css" rel="stylesheet">
  <!-- Your custom styles (optional) -->
  <link href="css/style.css" rel="stylesheet">
</head>

<body>
	<?php
	//this page is taking the values via id from the previous page
	$edit = $_GET['id'];
	//fetching all the data from database and then show them into input fields
	$execute = "SELECT * FROM users WHERE id = '$edit'";
	$result = mysqli_query($conn,$execute);
	//getting all the data from database into form of array
	$fetch = mysqli_fetch_array($result);

	//getting the database values of selected row
	$UserName = $fetch['username'];
	$Email = $fetch['email'];
	$MobileNumber = $fetch['mobilenumber'];
	$FullName = $fetch['fullname'];
	$Company = $fetch['company'];
	$Salary = $fetch['salary'];
	$Address = $fetch['address'];
	$CNIC = $fetch['cnic'];
	$BankTitle = $fetch['banktitle'];
	$BankAccountNumber = $fetch['bankaccount'];
	$BankSwift = $fetch['bankswift'];
	$JoiningDate = $fetch['joiningdate'];
	$GuardianName = $fetch['guardianname'];         
	?>

	<div class="container mt-5">
		<h3>Edit Employee Data </h3>
	<form method="post"> 
        <!-- text formatting-->
        <b>
        <div class="form-group">
          <label for="username">Username:</label>
            <input type="username" name="empusername" class="form-control" placeholder="enter username" value="<?php echo $UserName ?>" required>
        </div>

        <div class="form-group">
          <label for="email">Email:</label>
            <input type="email" name="empemail" class="form-control" placeholder="enter email address" value="<?php echo $Email ?>" required>
        </div>

        <div class="form-group">
          <label for="Phone-number">Mobile #:</label>
            <input type="number" name="empphonenumber" class="form-control" placeholder="92300xxxxxxxxx" value="<?php echo $MobileNumber ?>"required>
        </div>

        <div class="form-group">
          <label for="Full Name">Full Name:</label>
            <input type="text" name="empfullname" class="form-control" placeholder="enter full name" value="<?php echo $FullName ?>" required>
        </div>

        <div class="form-group">
          <label for="Company">Company:</label>
            <input type="text" name="empcompany" class="form-control" placeholder="enter company" value="<?php echo $Company ?>"required>
        </div>

        <div class="form-group">
          <label for="Salary">Salary:</label>
            <input type="number" name="empsalary" class="form-control" placeholder="enter your current salary" value="<?php echo $Salary ?>" required>
        </div>

        <div class="form-group">
          <label for="Address">Address:</label>
            <input type="text" name="empaddress" class="form-control" placeholder="enter your address" value="<?php echo $Address ?>" required>
        </div>

        <div class="form-group">
          <label for="CNIC">CNIC #:</label>
            <input type="number" name="empcnic" class="form-control" placeholder="31303-xxxxxxxx-xxxx" value="<?php echo $CNIC ?>" required>
        </div>

        <div class="form-group">
          <label for="Bank-title">Name of a Bank:</label>
            <input type="text" name="empbanktitle" class="form-control" placeholder="enter your bank name" value="<?php echo $BankTitle ?>" required>
        </div>

        <div class="form-group">
          <label for="Bank-account">Bank Account Number:</label>
            <input type="number" name="empaccountnumber" class="form-control" placeholder="enter account number" value="<?php echo $BankAccountNumber ?>" required>
        </div>

        <div class="form-group">
          <label for="Bank-swift">Bank Swift:</label>
            <input type="text" name="empbankswift" class="form-control" placeholder="enter bank swift code" value="<?php echo $BankSwift ?>" required>
        </div>

        <div class="form-group">
          <label for="Joining-date">Joining Date:</label>
            <input type="date" name="empjoindate" class="form-control" placeholder="enter joining data" value="<?php echo $JoiningDate ?>"required>
        </div>

        <div class="form-group">
          <label for="Guardian Name">Guardian Name:</label>
            <input type="text" name="empguardianname" class="form-control" placeholder="enter guardian name" value="<?php echo $GuardianName ?>" required>
        </div>
        <!-- text formatting end -->
      </b>
       <div class="form-group">
            <input type="submit" name="fsubmit" class="btn btn-success" value="Update Data">
            <a href="show.php" class="btn btn-primary">Show</a>
        </div>

        <div class="form-group">
            <input type="submit" class="btn btn-success" value="Submit">
            <a href="show.php" class="btn btn-primary">Show</a>
        </div>
      </form>
      </div>

      <?php
      //finally
      if(isset($_POST['fsubmit'])){
      	//getting values from user
$UserName = $_POST['empusername'];
$Email = $_POST['empemail'];
$Mobile = $_POST['empphonenumber'];
$FullName = $_POST['empfullname'];
$Company = $_POST['empcompany'];
$Salary = $_POST['empsalary'];
$Address = $_POST['empaddress'];
$CNIC = $_POST['empcnic'];
$BankTitle = $_POST['empbanktitle'];
$BankAccountNumber = $_POST['empaccountnumber'];
$BankSwift = $_POST['empbankswift'];
$JoiningDate = $_POST['empjoindate'];
$GuardianName = $_POST['empguardianname'];
//query of updating data
$update = "UPDATE users SET username='$UserName', email='$Email', mobilenumber='$Mobile', fullname='$FullName', company='$Company', salary='$Salary', address='$Address', cnic='$CNIC', banktitle='$BankTitle', bankaccount='$BankAccountNumber', bankswift='$BankSwift', joiningdate='$JoiningDate', guardianname='$GuardianName' WHERE id='$edit'";
mysqli_query($conn,$update);
header("Location: show.php");
}
?>

<!-- SCRIPTS -->
  <!-- JQuery -->
  <script type="text/javascript" src="js/jquery-3.3.1.min.js"></script>
  <!-- Bootstrap tooltips -->
  <script type="text/javascript" src="js/popper.min.js"></script>
  <!-- Bootstrap core JavaScript -->
  <script type="text/javascript" src="js/bootstrap.min.js"></script>
  <!-- MDB core JavaScript -->
  <script type="text/javascript" src="js/mdb.js"></script>
</body>

</html>
