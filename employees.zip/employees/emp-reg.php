<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <title>Employees Register Form</title>
  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css">
  <!-- Bootstrap core CSS -->
  <link href="css/bootstrap.min.css" rel="stylesheet">
  <!-- MD Bootstrap -->
  <link href="css/mdb.min.css" rel="stylesheet">
  <!-- Custom Css -->
  <link href="css/style.css" rel="stylesheet">
</head>

<body>
  <!-- Register Form -->
  <div class="container ml-5 mr-5 mt-3">
    <h3>Employee Registration</h3>
    <div class="col-sm-12">
      <form action="db-connect.php" method="post"> 
        <!-- text formatting-->
        <b>
        <div class="form-group">
          <label for="username">Username:</label>
            <input type="username" name="empusername" class="form-control" placeholder="enter username" required>
        </div>

        <div class="form-group">
          <label for="email">Email:</label>
            <input type="email" name="empemail" class="form-control" placeholder="enter email address" required>
        </div>

        <div class="form-group">
          <label for="Phone-number">Mobile #:</label>
            <input type="number" name="empphonenumber" class="form-control" placeholder="92300xxxxxxxxx" required>
        </div>

        <div class="form-group">
          <label for="Full Name">Full Name:</label>
            <input type="text" name="empfullname" class="form-control" placeholder="enter full name" value="Mr. / Miss. " required>
        </div>

        <div class="form-group">
          <label for="Company">Company:</label>
            <input type="text" name="empcompany" class="form-control" placeholder="enter company" required>
        </div>

        <div class="form-group">
          <label for="Salary">Salary:</label>
            <input type="number" name="empsalary" class="form-control" placeholder="enter your current salary" required>
        </div>

        <div class="form-group">
          <label for="Address">Address:</label>
            <textarea type="text" name="empaddress" class="form-control" placeholder="enter your address" required></textarea>
        </div>

        <div class="form-group">
          <label for="CNIC">CNIC #:</label>
            <input type="number" name="empcnic" class="form-control" placeholder="31303-xxxxxxxx-xxxx" required>
        </div>

        <div class="form-group">
          <label for="Bank-title">Name of a Bank:</label>
            <input type="text" name="empbanktitle" class="form-control" placeholder="enter your bank name" required>
        </div>

        <div class="form-group">
          <label for="Bank-account">Bank Account Number:</label>
            <input type="number" name="empaccountnumber" class="form-control" placeholder="enter account number" required>
        </div>

        <div class="form-group">
          <label for="Bank-swift">Bank Swift:</label>
            <input type="text" name="empbankswift" class="form-control" placeholder="enter bank swift code" required>
        </div>

        <div class="form-group">
          <label for="Joining-date">Joining Date:</label>
            <input type="date" name="empjoindate" class="form-control" placeholder="enter joining data" required>
        </div>

        <div class="form-group">
          <label for="Guardian Name">Guardian Name:</label>
            <input type="text" name="empguardianname" class="form-control" placeholder="enter guardian name" value="Mr. / Miss. " required>
        </div>
        <!-- text formatting end -->
      </b>

        <div class="form-group">
            <input type="submit" class="btn btn-success" value="Submit">
            <a href="show.php" class="btn btn-primary">Show</a>
        </div>

      </form>
    </div>
  </div>

  <!-- SCRIPTS -->
  <!-- JQuery -->
  <script type="text/javascript" src="js/jquery-3.3.1.min.js"></script>
  <!-- Bootstrap tooltips -->
  <script type="text/javascript" src="js/popper.min.js"></script>
  <!-- Bootstrap core JavaScript -->
  <script type="text/javascript" src="js/bootstrap.min.js"></script>
  <!-- MDB core JavaScript -->
  <script type="text/javascript" src="js/mdb.js"></script>
</body>

</html>
